package com.example.cfl_nav;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class MyDBHandler extends SQLiteOpenHelper {
    //information of database

    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "companyDB.db";
    public static final String TABLE_NAME = "Company";
    public static final String COLUMN_NAME = "CompanyName";
    public static final String COLUMN_SKILL = "CompanySkill";


    //initialize the database
    public MyDBHandler(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        System.out.println("\n\n\nHii  construct\n*\n*\n*\n*");
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        System.out.println("\n\n\nHii  oncreate\n*\n*\n*\n*");
        String CREATE_TABLE = "CREATE TABLE " + TABLE_NAME + " ( " + COLUMN_NAME + " TEXT , " + COLUMN_SKILL + " TEXT )";
        db.execSQL(CREATE_TABLE);


    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {}
    public String loadHandler() {String result = "";
        String query = "Select * FROM " + TABLE_NAME;
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(query, null);
        while (cursor.moveToNext()) {
            int result_0 = cursor.getInt(0);
            String result_1 = cursor.getString(1);
            result += String.valueOf(result_0) + " " + result_1 +
                    System.getProperty("line.separator");
            result=result_1;
        }
        cursor.close();
        db.close();
        return result;}
    public void addHandler(Company company) {

        ContentValues values = new ContentValues();
        values.put(COLUMN_SKILL, company.getCompanySkill());
        values.put(COLUMN_NAME, company.getCompanyName());
        SQLiteDatabase db = this.getWritableDatabase();
        db.insert(TABLE_NAME, null, values);
        db.close();
    }
    public Company findHandler(String companyname) {

        String[] namelist={"TSYS","JBHUNT","ACCENTURE","360","LINODE","MCLEOD","VOICEFLOW","EMCOR","MI","NOUSYSTEMS","SITEONE","BROOKSOURCE"};
        String[] skills1={".NET,SQL",".ANDROID STUDIO,SHELL SCRIPTING","C++,ACTIVE MQ","JAVA,PYTHON","PYTHON,C#",".NET,APIM","SWIFT,KOTLIN","IOS,JAVA","AWS,JAVA","C#,JAVA","C++,PYTHON","java,C++"};
        System.out.println("Hi");
        SQLiteDatabase db = this.getWritableDatabase();

        for(int itr=0;itr<12;itr++) {
            ContentValues values = new ContentValues();
            values.put(COLUMN_NAME, namelist[itr]);
            values.put(COLUMN_SKILL, skills1[itr]);
            db.insert(TABLE_NAME,null, values);
            System.out.println("Inserting row "+itr);
        }


        System.out.println("Hiii");
        String query = "Select * FROM " + TABLE_NAME + " WHERE " + COLUMN_NAME + " = " + "'" + companyname + "'";
        System.out.println("Hiii");
//        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(query, null);
        Company company = new Company();
        if (cursor.moveToFirst()) {
            cursor.moveToFirst();
            company.setCompanyName(cursor.getString(0));
            company.setCompanySkill(cursor.getString(1));
            cursor.close();
        } else {
            company = null;
        }
        db.close();
        return company;

    }

    public boolean updateHandler(int ID, String name) {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues args = new ContentValues();
        args.put(COLUMN_NAME, ID);
        args.put(COLUMN_NAME, name);
        return db.update(TABLE_NAME, args, COLUMN_NAME + "=" + ID, null) > 0;
    }
}