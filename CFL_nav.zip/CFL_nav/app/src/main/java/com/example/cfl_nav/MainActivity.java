package com.example.cfl_nav;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;
import android.widget.ImageButton;
import android.widget.TextView;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

public class MainActivity extends AppCompatActivity {

    String[] Fav={"No","No","No","No","No","No","No","No","No","No","No","No"};
    int checkindex=1;
    Button PrevButton=null;
    public void showCompanyDetails(View view) {
        if(PrevButton!=null)
            PrevButton.setBackgroundColor(Color.parseColor("#00ccb4"));
        Button companybtn=(Button)view;
        PrevButton=companybtn;
        TextView CompanyText = findViewById(R.id.CompanyDetails);
        CompanyText.setBackgroundColor(Color.YELLOW);

        ImageButton favbtn= findViewById(R.id.fav);
        favbtn.setVisibility('1');
        companybtn.setBackgroundColor(Color.YELLOW);
        String btninput=companybtn.getText().toString();
        MyDBHandler dbHandler = new MyDBHandler(this);
        Company result = dbHandler.findHandler(btninput);
        System.out.println("................................................................................\n");
        String skills=result.getCompanySkill();
        String[] arrskills= skills.split(",");
        skills="REQUIRED SKILLS: \n";
        for ( String ss : arrskills) {
            skills=skills+"\n"+ss;
        }
        CompanyText.setText(skills);


    }




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        BottomNavigationView navView = findViewById(R.id.nav_view);
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        AppBarConfiguration appBarConfiguration = new AppBarConfiguration.Builder(
                R.id.navigation_home, R.id.navigation_dashboard, R.id.navigation_notifications)
                .build();
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);
        NavigationUI.setupWithNavController(navView, navController);
    }

}
