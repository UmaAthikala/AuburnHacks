package com.example.cfl_nav;

public class Company {
    // fields
    private String companyName;
    private String companySkill;
    // consIDtructors
    public Company() {}
    public Company(String companyname, String companyskill) {
        this.companyName = companyname;
        this.companySkill = companyskill;
    }
    // properties
    public void setCompanySkill(String companySkill) {
        this.companySkill = companySkill;
    }
    public String getCompanySkill() {
        return this.companySkill;
    }
    public void setCompanyName(String companyname) {
        this.companyName = companyname;
    }
    public String getCompanyName() {
        return this.companyName;
    }
}